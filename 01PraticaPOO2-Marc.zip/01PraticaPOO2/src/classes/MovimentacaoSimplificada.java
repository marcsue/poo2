package classes;

public class MovimentacaoSimplificada extends Movimentacao
{
	public void tipoMovimentacao()
	{

		System.out.println("Movimentacao Simplificada");
	}

	
}