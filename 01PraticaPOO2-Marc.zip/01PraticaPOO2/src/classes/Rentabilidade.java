package classes;

public abstract class Rentabilidade 
{
	public abstract void mostrarRentabilidade();
}