package classes;

public class RentabilidadeBaixa extends Rentabilidade
{
	public void mostrarRentabilidade()
	{

		System.out.println("Rentabilidade Baixa");
	}
}