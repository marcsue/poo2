package classes;

public class MensalidadeNormal extends Mensalidade
{
	public void mostraMensalidade()
	{

		System.out.println("Mensalidade Normal");
	}
}