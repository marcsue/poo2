package classes; 

public abstract class Limite 
{
	public abstract void mostrarLimite();
}