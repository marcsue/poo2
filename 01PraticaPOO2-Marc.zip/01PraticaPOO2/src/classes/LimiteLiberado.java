package classes;


public class LimiteLiberado extends Limite
{
	public void mostrarLimite()
	{
		System.out.println("Conta Limite Liberado");
	}
}