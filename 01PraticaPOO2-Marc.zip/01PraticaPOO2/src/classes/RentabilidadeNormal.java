package classes;

public class RentabilidadeNormal extends Rentabilidade
{
	public void mostrarRentabilidade()
	{
		System.out.println("Rentabilidade Normal");
	}
}