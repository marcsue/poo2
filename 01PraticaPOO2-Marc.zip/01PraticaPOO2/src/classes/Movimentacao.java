package classes;

public abstract class Movimentacao 
{
	public abstract void tipoMovimentacao();
}