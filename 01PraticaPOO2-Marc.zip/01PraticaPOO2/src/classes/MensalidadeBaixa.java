package classes;

public class MensalidadeBaixa extends Mensalidade
{
	public void mostraMensalidade() {
		System.out.println("Mensalidade Baixa");
		
	}

}