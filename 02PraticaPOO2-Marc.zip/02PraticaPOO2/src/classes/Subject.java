package classes;

public interface Subject 
{
	public void adicionarObservador(Observer o);
	
	public void notificarObservador();
}
