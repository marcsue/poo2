package classes;


public class SanduicheFrango extends Sanduiche {
    
    public SanduicheFrango(){
        descricao = "Saunduiche de Frango";
    }
    
    public float calcularPreco(){
        return(float) 10.00;
    }
    
}
