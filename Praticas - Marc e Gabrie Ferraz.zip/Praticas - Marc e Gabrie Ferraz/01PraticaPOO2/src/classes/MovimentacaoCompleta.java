package classes;

public class MovimentacaoCompleta extends Movimentacao
{
	public void tipoMovimentacao()
	{

		System.out.println("Movimentacao Completa");
	}

	
}