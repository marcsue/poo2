package classes;

public abstract class Mensalidade 
{
	public abstract void mostraMensalidade();
}