package classes;

public class LimiteBloqueado extends Limite
{
	public void mostrarLimite()
	{
		System.out.println("Conta com Limite Bloqueado");
	}
}