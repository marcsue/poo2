package product;

public interface AbstractProduct {
}
