package factory;

public class ConcreteFactory extends AbstractFactory {

    @Override
    void createProduct(int[5] quantity) {

    }
}
