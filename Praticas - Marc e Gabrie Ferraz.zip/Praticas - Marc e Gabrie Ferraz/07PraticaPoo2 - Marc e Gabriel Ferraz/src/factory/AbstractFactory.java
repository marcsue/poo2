package factory;

public abstract  class AbstractFactory {

    abstract void createProduct(int[5] quantity);
}
