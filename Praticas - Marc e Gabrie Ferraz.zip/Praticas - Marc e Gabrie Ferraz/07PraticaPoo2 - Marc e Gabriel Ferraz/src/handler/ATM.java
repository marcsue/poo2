package handler;


public abstract class ATM {
    public abstract String handleRequest(int request);
}
