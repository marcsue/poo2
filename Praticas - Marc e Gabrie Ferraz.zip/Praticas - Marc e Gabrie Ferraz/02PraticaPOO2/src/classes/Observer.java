package classes;

public interface Observer 
{
	public void atualizar(Subject s);
	
	
}
