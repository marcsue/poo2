package classes;

public interface ExpressaoLogica 
{
	public boolean operacao();

}
