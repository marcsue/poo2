package classes;

public class ComandoNenhum implements Comando {
	public void executar() {
	}
}
