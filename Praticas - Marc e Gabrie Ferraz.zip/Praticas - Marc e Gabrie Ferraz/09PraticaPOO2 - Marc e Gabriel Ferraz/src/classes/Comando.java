package classes;

public interface Comando {
	
	public void executar();

}
