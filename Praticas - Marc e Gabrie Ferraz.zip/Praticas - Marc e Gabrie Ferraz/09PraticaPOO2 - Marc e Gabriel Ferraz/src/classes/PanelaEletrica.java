package classes;

public class PanelaEletrica {

	
	public void ligarPanela()
	{
		System.out.println("Ligando panela");
	}
	
	public void desligarPanela()
	{
		System.out.println("Desligando panela");
	}
}
