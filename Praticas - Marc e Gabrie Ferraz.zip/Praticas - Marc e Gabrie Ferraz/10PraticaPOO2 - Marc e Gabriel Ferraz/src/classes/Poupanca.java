package classes;

public class Poupanca extends AbirContaTemplate
{

	
	public void cadastrarPessoa() {
		System.out.println("Cadastrando Pessoa Fisica");		
	}

	public void validarPessoa() {
		System.out.println("Validando Pessoa Fisica no SPC");
		
	}

	public void depositarValorInicial() {
		System.out.println("Depositando valor inicial da poupanca");
		
	}

	public void cadastrarSenha() {
		System.out.println("Cadastrando Senha Poupanca");
		
	}
	
	public void finalizar() {
		System.out.println("Finalizando abertura conta Poupanca");
		
	}

}
