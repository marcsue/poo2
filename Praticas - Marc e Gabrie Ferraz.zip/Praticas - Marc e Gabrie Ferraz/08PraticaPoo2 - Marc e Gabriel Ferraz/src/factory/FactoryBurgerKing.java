package factory;

public class FactoryBurgerKing implements AbstractFactory {
    @Override
    public String getName() {
        return "Burger King";
    }
}
