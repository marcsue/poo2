package factory;

public class FactoryMcDonalds implements AbstractFactory {
    @Override
    public String getName() {
        return "Mc Donalds";
    }


}
