package factory;

public interface AbstractFactory {

    String getName();
}
