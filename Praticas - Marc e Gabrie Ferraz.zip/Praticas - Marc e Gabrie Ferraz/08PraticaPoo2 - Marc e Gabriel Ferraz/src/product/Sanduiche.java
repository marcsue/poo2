package product;

public interface Sanduiche {

    Sanduiche preparar();
}
