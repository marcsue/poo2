package store;

import product.Sanduiche;

public interface Store {

    Sanduiche order();
}
