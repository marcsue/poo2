package padrao.adapter;

public class Account {
    int numero = 10;
    
    public Account(int x){
        this.numero = x;
    }
    
    public int getNumero(){
        return this.numero;
    }
    
}
