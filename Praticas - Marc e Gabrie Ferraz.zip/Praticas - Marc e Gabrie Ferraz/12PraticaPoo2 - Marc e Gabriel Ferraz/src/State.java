public interface State {

    State pegarCogumelo();
    State pegarFlor();
    State pegarPena();
    State levarDano();
}
