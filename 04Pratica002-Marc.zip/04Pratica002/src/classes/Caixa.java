package classes;

public abstract class Caixa {
    
    Caixa next;
    
    public abstract void contaNotas(int valor);
    
}
