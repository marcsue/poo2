package classes;


public abstract class AdicionalDecorator extends Sanduiche{
    
    public abstract String getDescricao();
    
}
