package classes;

public class SanduicheVeg extends Sanduiche {
    
    public SanduicheVeg(){
        descricao = "Saunduiche Vegetariano";
    }
    
    public float calcularPreco(){
        return(float) 8.00;
    }
    
}
